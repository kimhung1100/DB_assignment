

-- CATEGORY

INSERT INTO CATEGORY (category_name) VALUES
    ('Văn học'),
    ('Khoa học Kỹ thuật'),
    ('Sách giáo khoa'),
    ('Kinh tế'),
    ('Lịch sử - Địa Lý - Tôn giáo'),
    ('Nuôi dạy con'),
    ('Chính trị - Pháp lý - Triết học'),
    ('Từ điển'),
    ('Văn hoá - Nghệ thuật - Du lịch'),
    ('Thể dục thể thao - Giải trí'),
    ('Âm nhạc - Mỹ thuật - Thời Trang'),
    ('Báo - Tạp chí'),
    ('Giáo trình'),
    ('Làm vười - Thú nuôi');

# SELECT * FROM CATEGORY;

-- BOOK
CREATE TABLE BOOK (
    ISBN VARCHAR(13) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    book_cover ENUM('hardcover', 'paperback') NOT NULL,
    description LONGTEXT NOT NULL,
    dimensions VARCHAR(20) NOT NULL,
    print_length INT NOT NULL,
    price INT NOT NULL,
    publication_date DATE NOT NULL,
    publisher INT NOT NULL,
    FOREIGN KEY (publisher) REFERENCES PUBLISHER(publisher_id)
);

INSERT INTO BOOK (ISBN, title, book_cover, description, dimensions, print_length, price, publication_date, publisher)
VALUES
    ('8935092820392', 'Phương Pháp Giải Các Chủ Đề Căn Bản Đại Số 10 (Biên Soạn Theo Chương Trinh GDPT Mới) (Dùng Chung Cho Các Bộ SGK Hiện Hành)',
     'paperback', 'Phương Pháp Giải Các Chủ Đề Căn Bản Đại Số 10 (Biên Soạn Theo Chương Trinh GDPT Mới) (Dùng Chung Cho Các Bộ SGK Hiện Hành)

Nhằm mục đích giúp các bạn học sinh lớp 10, lớp 11, lớp 12 có nền tảng Toán căn bản ngay từ lúc vào THPT, bắt đầu lớp 10 nhiều bỡ ngỡ về kiến thức và cách giảng dạy rồi lên lớp 11, lớp 12 chuẩn bị thi Tốt nghiệp, tuyển sinh Cao đẳng, Đại học.

Từ nền Toán căn bản này các bạn có thể nâng cao dần dần, bổ sung và mở rộng kiến thức và phương pháp giải Toán, rèn luyện kỹ năng làm bài và từng bước giải đúng, giải gọn các bài tập, các bài toán kiểm tra, thi cử.

Cuốn Phương Pháp Giải Các Chủ Đề Căn Bản Đại Số 10 có 17 chủ đề với nội dung là phân dạng Toán, tóm tắt kiến thức và phương pháp giải, các chú ý, phần tiếp theo là các bài toán chọn lọc căn bản minh họa với nhiều dạng loại và mức độ, phần cuối là 8 bài tập có hướng dẫn hay đáp số.

Mã hàng	8935092820392
Nhà Cung Cấp	CÔNG TY CỔ PHẦN SÁCH VÀ VĂN HÓA PHẨM MIỀN NAM
Tác giả	Lê Hoành Phò
NXB	Đại Học Quốc Gia Hà Nội
Năm XB	2022
Trọng lượng (gr)	332
Kích Thước Bao Bì	24 x 17 x 1.2 cm
Số trang	323
Hình thức	Bìa Mềm
Sản phẩm bán chạy nhất	Top 100 sản phẩm Tham Khảo Lớp 10 bán chạy của tháng
Giá sản phẩm trên Fahasa.com đã bao gồm thuế theo luật hiện hành. Bên cạnh đó, tuỳ vào loại sản phẩm, hình thức và địa chỉ giao hàng mà có thể phát sinh thêm chi phí khác như Phụ phí đóng gói, phí vận chuyển, phụ phí hàng cồng kềnh,...
Chính sách khuyến mãi trên Fahasa.com không áp dụng cho Hệ thống Nhà sách Fahasa trên toàn quốc
Phương Pháp Giải Các Chủ Đề Căn Bản Đại Số 10 (Biên Soạn Theo Chương Trinh GDPT Mới) (Dùng Chung Cho Các Bộ SGK Hiện Hành)

Nhằm mục đích giúp các bạn học sinh lớp 10, lớp 11, lớp 12 có nền tảng Toán căn bản ngay từ lúc vào THPT, bắt đầu lớp 10 nhiều bỡ ngỡ về kiến thức và cách giảng dạy rồi lên lớp 11, lớp 12 chuẩn bị thi Tốt nghiệp, tuyển sinh Cao đẳng, Đại học.

Từ nền Toán căn bản này các bạn có thể nâng cao dần dần, bổ sung và mở rộng kiến thức và phương pháp giải Toán, rèn luyện kỹ năng làm bài và từng bước giải đúng, giải gọn các bài tập, các bài toán kiểm tra, thi cử.

Cuốn Phương Pháp Giải Các Chủ Đề Căn Bản Đại Số 10 có 17 chủ đề với nội dung là phân dạng Toán, tóm tắt kiến thức và phương pháp giải, các chú ý, phần tiếp theo là các bài toán chọn lọc căn bản minh họa với nhiều dạng loại và mức độ, phần cuối là 8 bài tập có hướng dẫn hay đáp số.',
     '24 x 17 x 1.2 cm', 323, 93500, '2022-01-01', 1);

-- BOOK IMAGE
INSERT INTO IMAGE_BOOK(ISBN, img_link) VALUES ('8935092820392','https://cdn0.fahasa.com/media/flashmagazine/images/page_images/phuong_phap_giai_cac_chu_de_can_ban_dai_so_10_bien_soan_theo_chuong_trinh_gdpt_moi_dung_chung_cho_cac_bo_sgk_hien_hanh/2023_10_28_10_45_35_1-390x510.jpg');

-- AUTHOR

INSERT INTO AUTHOR(author_name) VALUES ('Nhiều tác giả');

INSERT INTO PUBLISHER(publisher_name) VALUES ('ĐHQG Hà Nội');

SELECT * from BOOK;

SELECT 1;